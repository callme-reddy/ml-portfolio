export default function Portfolio() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial', color: '#fff', background: '#111', minHeight: '100vh' }}>
      <h1>Machine Learning Engineer Portfolio</h1>
      <p>Welcome to my professional portfolio site.</p>
    </div>
  );
}